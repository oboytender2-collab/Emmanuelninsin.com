WEB6 PERSONAL WEBSITE

This package is designed for GitHub Pages.

IMPORTANT: Extract this ZIP first, then upload all extracted files and folders to the ROOT of your GitHub repository. Do not upload only the ZIP file.

Open index.html as the home page. Each menu link opens its own dedicated page: About Me, Daily Bible Verse, Quote of the Day, Sports Updates, Education, Leadership, Law & Justice, My Story, Biography, My Book, Achievements, Teaching, and Contact.

Files to upload include all .html pages, styles.css, script.js, emmanuel-profile.png, and Education_Is_Key_to_Life_Print_Ready.pdf.

To publish: GitHub repository > Settings > Pages > Deploy from a branch > choose main and /(root) > Save.

The site uses the free GitHub Pages web address. A custom domain such as emmanuelninsin.com must be registered separately.
