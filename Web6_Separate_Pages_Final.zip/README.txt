WEB6 PERSONAL WEBSITE — SEPARATE PAGES FINAL

Each top menu item links to its own HTML page, not a section on the homepage.

Pages included:
- index.html (Home)
- about.html (About Me)
- bible-verse.html (Daily Bible Verse)
- quote.html (Quote of the Day)
- sports.html (Sports Updates)
- education.html (Education)
- leadership.html (Leadership)
- law-justice.html (Law & Justice)
- my-story.html (My Story)
- biography.html (Biography)
- my-book.html (My Book)
- achievements.html (Achievements)
- teaching.html (Teaching)
- contact.html (Contact)

IMPORTANT FOR GITHUB PAGES:
1. Extract this ZIP on your phone/computer.
2. Open the extracted folder.
3. Upload the CONTENTS of this folder directly into the ROOT of the GitHub repository (where the current index.html is). Do not upload the ZIP itself and do not upload the containing folder as a nested folder.
4. If prompted, replace/overwrite the old files, then Commit changes.
5. In Settings > Pages, publish from branch main and folder /(root).
6. Wait a few minutes, then refresh the live website. If it still shows the old scrolling menu, check that index.html was replaced in the repository root and that the new pages are alongside it.

GitHub Pages hosting is free. A custom domain must be registered separately.
